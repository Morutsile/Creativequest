package com.creativequest

import android.content.Context
import android.os.Bundle
import java.security.MessageDigest
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{CreativeQuestApp(this)}}
}
fun pinHash(s:String)=MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString(""){"%02x".format(it)}

@Composable fun CreativeQuestApp(ctx:Context){
 val p=ctx.getSharedPreferences("creative_quest",Context.MODE_PRIVATE)
 var name by remember{mutableStateOf(p.getString("name","")?:"")}
 var avatar by remember{mutableStateOf(p.getString("avatar","🦊")?:"🦊")}
 var stars by remember{mutableIntStateOf(p.getInt("stars",0))}
 var questsDone by remember{mutableIntStateOf(p.getInt("quests",0))}
 var screen by remember{mutableStateOf(if(name.isBlank())"setup" else "home")}
 var activity by remember{mutableStateOf("Draw")}
 var wild by remember{mutableStateOf(false)}
 var pin by remember{mutableStateOf("")}
 var pinError by remember{mutableStateOf("")}
 val go:(String)->Unit={screen=it}

 MaterialTheme{
  Column(Modifier.fillMaxSize().background(Color(0xFFF5F3FF))){
   when(screen){
    "setup"->Setup(name,{name=it},avatar,{avatar=it},{
      val n=name.ifBlank{"Explorer"};p.edit().putString("name",n).putString("avatar",avatar).apply();name=n;screen="home"})
    "home"->Home(name,avatar,stars,questsDone,{go("quests")},{go("profile")},{go("gallery")},{go("parent")})
    "quests"->QuestList({title->activity=title;screen="activity"},{wild=!wild},{go("home")})
    "activity"->Activity(activity,wild,{screen="complete"},{go("quests")})
    "complete"->{stars+=50;questsDone+=1;p.edit().putInt("stars",stars).putInt("quests",questsDone).apply();Complete(stars,questsDone,{go("home")},{go("gallery")})}
    "profile"->Profile(name,avatar,stars,questsDone,{go("home")})
    "gallery"->Gallery({go("home")})
    "parent"->ParentGate(pin,{pin=it;pinError=""},{
       if(p.getString("parentPin",null)==null && pin.length==4){p.edit().putString("parentPin",pinHash(pin)).apply();pin="";screen="parentDash"}
       else if(pin.length==4 && pinHash(pin)==p.getString("parentPin","")){pin="";screen="parentDash"} else pinError="Incorrect PIN"
     },{go("home")},pinError,p.getString("parentPin",null)==null)
    "parentDash"->ParentDash({go("home")})
   }
   Spacer(Modifier.weight(1f))
   if(screen!="setup" && screen!="parent" && screen!="parentDash")Nav(screen,{go("home")},{go("quests")},{go("gallery")},{go("profile")})
  }
 }
}

@Composable fun Nav(screen:String,home:()->Unit,quests:()->Unit,gallery:()->Unit,profile:()->Unit){
 NavigationBar{
  NavigationBarItem(screen=="home",home,{Text("🏠")},{Text("Home")})
  NavigationBarItem(screen=="quests",quests,{Text("🚩")},{Text("Quests")})
  NavigationBarItem(screen=="gallery",gallery,{Text("🖼️")},{Text("Gallery")})
  NavigationBarItem(screen=="profile",profile,{Text("⭐")},{Text("Profile")})
 }
}
@Composable fun Header(name:String,avatar:String,stars:Int,parent:()->Unit){
 Row(Modifier.fillMaxWidth().padding(18.dp),Arrangement.SpaceBetween,Alignment.CenterVertically){
  Column{Text("Creative",27.sp,fontWeight=FontWeight.Black,color=Color(0xFF6C3FD4));Text("QUEST",21.sp,fontWeight=FontWeight.Black,color=Color(0xFFFFB900))}
  Row(verticalAlignment=Alignment.CenterVertically){Text("$avatar $name",fontWeight=FontWeight.Bold);Spacer(Modifier.width(8.dp));Text("⭐ $stars");TextButton(parent){Text("🔒")}}
 }
}
@Composable fun CardBox(content:@Composable ColumnScope.()->Unit){Card(Modifier.fillMaxWidth().padding(8.dp,7.dp),RoundedCornerShape(23.dp)){Column(Modifier.padding(17.dp),content=content)}}
@Composable fun Btn(text:String,onClick:()->Unit){Button(onClick,shape=RoundedCornerShape(17.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFFFC928))){Text(text,color=Color(0xFF35166E),fontWeight=FontWeight.Black)}}

@Composable fun Setup(name:String,setName:(String)->Unit,avatar:String,setAvatar:(String)->Unit,save:()->Unit){
 Column(Modifier.fillMaxSize().padding(24.dp),Arrangement.Center){
  Text("🌈 Creative Quest",32.sp,fontWeight=FontWeight.Black,color=Color(0xFF6C3FD4));Text("Create your Explorer profile.",20.sp)
  Spacer(Modifier.height(16.dp));OutlinedTextField(name,setName,label={Text("Your name")},singleLine=true)
  Spacer(Modifier.height(12.dp));Text("Choose an avatar",fontWeight=FontWeight.Bold)
  Row{listOf("🦊","🐼","🐸","🦄","🚀").forEach{a->TextButton({setAvatar(a)}){Text(a,30.sp)}}}
  Spacer(Modifier.height(16.dp));Btn("Start Creating →",save)
 }
}
@Composable fun Home(name:String,avatar:String,stars:Int,done:Int,quests:()->Unit,profile:()->Unit,gallery:()->Unit,parent:()->Unit){
 Header(name,avatar,stars,parent)
 CardBox{Text("Hi, $name! $avatar",23.sp,fontWeight=FontWeight.Black);Text("Your imagination is your superpower.");Spacer(Modifier.height(12.dp));Btn("Start Today's Quest →",quests)}
 CardBox{Text("🔥 Creative streak",fontWeight=FontWeight.Bold);Text("Keep creating every day!")}
 CardBox{Text("🏅 Progress",fontWeight=FontWeight.Bold);Text("$done quests completed • $stars stars");TextButton(profile){Text("View Profile")}}
 CardBox{Text("🖼️ My creations",fontWeight=FontWeight.Bold);TextButton(gallery){Text("Open Gallery")}}
}
@Composable fun QuestList(start:(String)->Unit,toggleWild:()->Unit,back:()->Unit){
 Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){TextButton(back){Text("←")};Text("Creative Quests",24.sp,fontWeight=FontWeight.Bold)}
 val qs=listOf("Draw It ✏️","Story Maker 📖","Music Maker 🎵","Invent It 💡","Act It Out 🎭","Build It 🧱")
 qs.forEach{q->CardBox{Text(q,19.sp,fontWeight=FontWeight.Bold);Text("Create it your way.",color=Color.Gray);TextButton({start(q)}){Text("Choose →")}}}
 CardBox{Text("🔥 Make It WILD!",fontWeight=FontWeight.Bold);Text("Tap to add a surprise twist.");TextButton(toggleWild){Text("Wild Mode →")}}
}
@Composable fun Activity(type:String,isWild:Boolean,done:()->Unit,back:()->Unit){
 Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){TextButton(back){Text("←")};Text(type,24.sp,fontWeight=FontWeight.Bold)}
 CardBox{
  Text(if(isWild)"🔥 WILD QUEST" else "Today's Creative Quest",color=Color(0xFF6C3FD4),fontWeight=FontWeight.Black)
  Text(when(type){
   "Draw It ✏️"->"Design a home for an alien."
   "Story Maker 📖"->"Write a story about a robot who gets lost."
   "Music Maker 🎵"->"Create a rhythm for a dancing planet."
   "Invent It 💡"->"Invent something that solves a silly problem."
   "Act It Out 🎭"->"Act out a character from another world."
   else->"Build a bridge for a tiny dragon."
  },20.sp,fontWeight=FontWeight.Bold)
  Spacer(Modifier.height(10.dp))
  if(isWild)Text("🔥 WILD: Add something surprising!",fontWeight=FontWeight.Bold)
  Spacer(Modifier.height(15.dp))
  Box(Modifier.fillMaxWidth().height(260.dp).background(Color.White,RoundedCornerShape(20.dp)),Alignment.Center){
   Text(when(type){"Draw It ✏️"->"✏️ Draw here";"Story Maker 📖"->"📖 Write your story";"Music Maker 🎵"->"🎵 Tap a rhythm";"Invent It 💡"->"💡 Sketch your invention";"Act It Out 🎭"->"🎭 Practice your scene";else->"🧱 Plan your build"},28.sp,fontWeight=FontWeight.Bold,color=Color(0xFF6C3FD4))
  }
  Spacer(Modifier.height(12.dp));Btn("Finish Quest ✓",done)
 }
}
@Composable fun Complete(stars:Int,done:Int,home:()->Unit,gallery:()->Unit){
 CardBox{Text("🎉 Amazing!",30.sp,fontWeight=FontWeight.Black,color=Color(0xFF6C3FD4));Text("You made something new!");Spacer(Modifier.height(10.dp));Text("⭐ +50 Stars   🏅 Creativity Badge");Text("Total: $stars stars • $done quests");Spacer(Modifier.height(10.dp));Btn("View Gallery",gallery);TextButton(home){Text("Home")}}
}
@Composable fun Profile(name:String,avatar:String,stars:Int,done:Int,back:()->Unit){
 Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){TextButton(back){Text("←")};Text("My Profile",24.sp,fontWeight=FontWeight.Bold)}
 CardBox{Text("$avatar  $name",28.sp,fontWeight=FontWeight.Black);Text("⭐ $stars stars");Text("🚩 $done quests completed")}
 CardBox{Text("🏅 Badge Collection",fontWeight=FontWeight.Bold);Text("💡 Idea Maker   🔍 Explorer   🛠️ Builder");Text("🌟 Experimenter — keep creating!")}
 CardBox{Text("🌈 Creative Journey",fontWeight=FontWeight.Bold);Text("Try all six creative modes to discover new badges.")}
}
@Composable fun Gallery(back:()->Unit){
 Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){TextButton(back){Text("←")};Text("My Gallery",24.sp,fontWeight=FontWeight.Bold)}
 CardBox{Text("🛸 Alien Home",20.sp,fontWeight=FontWeight.Bold);Text("Private creation • saved on this device")}
 CardBox{Text("🤖 Robot Story",20.sp,fontWeight=FontWeight.Bold);Text("Private creation • saved on this device")}
 CardBox{Text("💡 My Invention",20.sp,fontWeight=FontWeight.Bold);Text("Private creation • saved on this device")}
}
@Composable fun ParentGate(pin:String,setPin:(String)->Unit,unlock:()->Unit,back:()->Unit,error:String,first:Boolean){
 Column(Modifier.fillMaxSize().padding(24.dp),Arrangement.Center){
  Text("🔒 Parent Area",28.sp,fontWeight=FontWeight.Black);Text(if(first)"Create a 4-digit parent PIN." else "Enter the parent PIN.")
  Spacer(Modifier.height(12.dp));OutlinedTextField(pin,{setPin(it.filter(Char::isDigit).take(4))},label={Text("4-digit PIN")},singleLine=true)
  if(error.isNotEmpty())Text(error,color=Color.Red)
  Spacer(Modifier.height(12.dp));Btn(if(first)"Create PIN" else "Unlock",if(pin.length==4)unlock else {});TextButton(back){Text("Cancel")}}
}
@Composable fun ParentDash(back:()->Unit){
 Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){TextButton(back){Text("←")};Text("Parent Dashboard",23.sp,fontWeight=FontWeight.Bold)}
 CardBox{Text("📊 Progress",20.sp,fontWeight=FontWeight.Bold);Text("Quests completed: 6");Text("Creative modes explored: 4");Text("Badges earned: 3")}
 CardBox{Text("🛡️ Safety & Privacy",fontWeight=FontWeight.Bold);Text("✓ No public messaging");Text("✓ No stranger contact");Text("✓ Creations private by default")}
 CardBox{Text("⏱️ Screen-time controls",fontWeight=FontWeight.Bold);Text("Daily limit controls can be configured for production release.")}
}
