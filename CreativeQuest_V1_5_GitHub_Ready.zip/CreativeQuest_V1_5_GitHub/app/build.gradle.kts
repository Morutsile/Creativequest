plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.creativequest"; compileSdk=35
 defaultConfig { applicationId="com.creativequest"; minSdk=24; targetSdk=35; versionCode=6; versionName="1.5.0" }
}
dependencies {
 implementation("androidx.core:core-ktx:1.15.0")
 implementation("androidx.activity:activity-compose:1.10.0")
 implementation(platform("androidx.compose:compose-bom:2024.12.01"))
 implementation("androidx.compose.ui:ui")
 implementation("androidx.compose.material3:material3")
 implementation("androidx.compose.foundation:foundation")
}