# Creative Quest V1.5

A child-focused creativity app prototype.

## Included
- Child onboarding and avatar
- Daily creative quests
- Six creative modes
- Make It WILD
- Stars, badges and progress
- Private gallery concept
- Parent PIN gate and dashboard
- Child-safety-first navigation

## Build the APK on GitHub
This repository includes a GitHub Actions workflow. After uploading the project to GitHub, open **Actions → Build Creative Quest APK → Run workflow**. When it finishes, download the `creative-quest-debug-apk` artifact and install the APK on an Android phone.

## Important
This is a source project/prototype. It is not a signed release APK/AAB and has not been independently tested on a physical Android device in this environment. Before publishing, test on supported Android versions, review child-privacy requirements, add production persistence for all creation types, and complete Google Play's current child/family declarations and app review requirements.
